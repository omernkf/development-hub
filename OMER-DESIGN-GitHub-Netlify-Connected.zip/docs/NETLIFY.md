# Netlify deployment from Development Hub

Use the existing Netlify **omdesign** site, not a new one.

1. Upload the entire contents of this package to `omernkf/development-hub` (root README, `projects/`, `docs/`, `site/`).
2. In Netlify, choose **Link to Git repository** for that existing project and select this repository, branch `main`.
3. Set **Base directory** empty, **Build command** empty, **Publish directory** `site`.
4. Save and deploy. Check the homepage and `/developer.html` after deployment.
5. Updates pushed to branch `main` then trigger Netlify redeploys.

Do not link the hub until `site/index.html` and its assets have been uploaded to GitHub: a missing publish directory makes deployment fail.

The site reads the public registry at `https://raw.githubusercontent.com/omernkf/development-hub/main/projects/projects.json`. Browser requests might be cached or unavailable; the page has fallbacks. Public data only.
