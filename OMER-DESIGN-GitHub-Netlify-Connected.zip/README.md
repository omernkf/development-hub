# OMER DESIGN · Development Hub

Central public repository containing the OMER DESIGN website source (`site/`) and a project index (`projects/`).

- [Live website](https://omdesign.netlify.app/)
- [Site source](site/)
- [Project registry](projects/projects.json)
- [Netlify connection instructions](docs/NETLIFY.md)

Projects: [NKF-Yemen](https://github.com/omernkf/nkf-yemen), [Yemen Phone AI](https://omdesign.netlify.app/portfolio.html), [Bin Mabrouk](https://bin-mabrouk.vercel.app/).

The registry does not include private repositories' code, credentials, or customer data. `solo.is-a.dev` is a proposed domain; use `omdesign.netlify.app` until approved.
